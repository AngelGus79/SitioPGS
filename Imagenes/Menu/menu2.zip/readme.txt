Here is the code to use; be sure to edit the [TEXT] and [URL] tag.
See test.htm for a test in use.
For more info: Mail me at kaybee278@hotmail.com
Good luck!

<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"
 WIDTH=125 HEIGHT=20>
 <PARAM NAME=movie VALUE="slidebutton.swf?text=[TEXT]&url=[URL]">
 <PARAM NAME=quality VALUE=high><PARAM NAME=bgcolor VALUE=#000000>
 <EMBED src="slidebutton.swf" quality=high bgcolor=#000000
  WIDTH=125 HEIGHT=20 TYPE="application/x-shockwave-flash" 
  PLUGINSPAGE="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash">
 </EMBED>
</OBJECT>